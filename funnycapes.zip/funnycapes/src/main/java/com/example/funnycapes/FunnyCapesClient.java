package com.example.funnycapes;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

public class FunnyCapesClient implements ClientModInitializer {
	public static final String MOD_ID = "funnycapes";

	/** Радиус поиска в блоках вокруг игрока. */
	private static final int RADIUS = 24;
	/** Как часто пересканировать мир (в тиках, 20 = раз в секунду). */
	private static final int SCAN_INTERVAL = 20;
	/** Прозрачность подсветки. */
	private static final float ALPHA = 0.45f;

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(MOD_ID, "pipeline/ore_filled_through_walls"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.build()
	);

	private static final ByteBufferBuilder ALLOCATOR = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
	private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
	private static final Vector3f MODEL_OFFSET = new Vector3f();
	private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

	private record Target(int x, int y, int z, float r, float g, float b) { }

	private MappableRingBuffer vertexBuffer;
	private volatile List<Target> targets = List.of();
	private boolean enabled = true;
	private int tickCounter = 0;

	@Override
	public void onInitializeClient() {
		KeyMapping.Category category = KeyMapping.Category.register(
			Identifier.fromNamespaceAndPath(MOD_ID, "main")
		);
		KeyMapping toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
			"key.funnycapes.toggle",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_O,
			category
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (toggleKey.consumeClick()) {
				enabled = !enabled;
				if (client.player != null) {
					client.player.displayClientMessage(
						Component.literal("Funny Capes: " + (enabled ? "ON" : "OFF")), true);
				}
				if (!enabled) {
					targets = List.of();
				} else {
					tickCounter = SCAN_INTERVAL; // пересканировать сразу
				}
			}

			if (!enabled) {
				return;
			}
			if (++tickCounter >= SCAN_INTERVAL) {
				tickCounter = 0;
				scan(client);
			}
		});

		WorldRenderEvents.BEFORE_TRANSLUCENT.register(this::render);

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
			ALLOCATOR.close();
			if (vertexBuffer != null) {
				vertexBuffer.close();
				vertexBuffer = null;
			}
		});
	}

	// ---------- Поиск руды ----------

	private void scan(Minecraft client) {
		ClientLevel level = client.level;
		LocalPlayer player = client.player;
		if (level == null || player == null) {
			targets = List.of();
			return;
		}

		BlockPos center = player.blockPosition();
		int minY = Math.max(level.getMinY(), center.getY() - RADIUS);
		int maxY = Math.min(level.getMaxY(), center.getY() + RADIUS);

		List<Target> found = new ArrayList<>();
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

		for (int x = center.getX() - RADIUS; x <= center.getX() + RADIUS; x++) {
			for (int z = center.getZ() - RADIUS; z <= center.getZ() + RADIUS; z++) {
				for (int y = minY; y <= maxY; y++) {
					pos.set(x, y, z);
					Block block = level.getBlockState(pos).getBlock();

					if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) {
						found.add(new Target(x, y, z, 0.1f, 0.9f, 1.0f));   // голубой
					} else if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) {
						found.add(new Target(x, y, z, 0.1f, 1.0f, 0.3f));   // зелёный
					}
				}
			}
		}
		targets = found;
	}

	// ---------- Рендер ----------

	private void render(WorldRenderContext context) {
		List<Target> list = targets;
		if (!enabled || list.isEmpty()) {
			return;
		}

		PoseStack matrices = context.matrices();
		Vec3 camera = context.worldState().cameraRenderState.pos;

		matrices.pushPose();
		matrices.translate(-camera.x, -camera.y, -camera.z);

		BufferBuilder buffer = new BufferBuilder(ALLOCATOR, PIPELINE.getVertexFormatMode(), PIPELINE.getVertexFormat());
		Matrix4fc pose = matrices.last().pose();
		final float e = 0.002f; // чуть больше блока, чтобы не мерцало
		for (Target t : list) {
			filledBox(pose, buffer,
				t.x() - e, t.y() - e, t.z() - e,
				t.x() + 1 + e, t.y() + 1 + e, t.z() + 1 + e,
				t.r(), t.g(), t.b(), ALPHA);
		}

		matrices.popPose();

		drawBuffer(Minecraft.getInstance(), buffer);
	}

	private static void filledBox(Matrix4fc m, BufferBuilder b,
								  float minX, float minY, float minZ,
								  float maxX, float maxY, float maxZ,
								  float r, float g, float bl, float a) {
		// front
		b.addVertex(m, minX, minY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, minY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, maxY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, maxY, maxZ).setColor(r, g, bl, a);
		// back
		b.addVertex(m, maxX, minY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, minY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, maxY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, maxY, minZ).setColor(r, g, bl, a);
		// left
		b.addVertex(m, minX, minY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, minY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, maxY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, maxY, minZ).setColor(r, g, bl, a);
		// right
		b.addVertex(m, maxX, minY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, minY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, maxY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, maxY, maxZ).setColor(r, g, bl, a);
		// top
		b.addVertex(m, minX, maxY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, maxY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, maxY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, maxY, minZ).setColor(r, g, bl, a);
		// bottom
		b.addVertex(m, minX, minY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, minY, minZ).setColor(r, g, bl, a);
		b.addVertex(m, maxX, minY, maxZ).setColor(r, g, bl, a);
		b.addVertex(m, minX, minY, maxZ).setColor(r, g, bl, a);
	}

	private void drawBuffer(Minecraft client, BufferBuilder buffer) {
		MeshData built = buffer.buildOrThrow();
		MeshData.DrawState drawState = built.drawState();
		VertexFormat format = drawState.format();

		GpuBuffer vertices = upload(drawState, format, built);
		draw(client, PIPELINE, built, drawState, vertices, format);

		vertexBuffer.rotate();
	}

	private GpuBuffer upload(MeshData.DrawState drawState, VertexFormat format, MeshData built) {
		int size = drawState.vertexCount() * format.getVertexSize();

		if (vertexBuffer == null || vertexBuffer.size() < size) {
			if (vertexBuffer != null) {
				vertexBuffer.close();
			}
			vertexBuffer = new MappableRingBuffer(
				() -> MOD_ID + " ore buffer",
				GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
				size
			);
		}

		CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
		try (GpuBuffer.MappedView view = encoder.mapBuffer(
			vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
			MemoryUtil.memCopy(built.vertexBuffer(), view.data());
		}
		return vertexBuffer.currentBuffer();
	}

	private static void draw(Minecraft client, RenderPipeline pipeline, MeshData built,
							 MeshData.DrawState drawState, GpuBuffer vertices, VertexFormat format) {
		GpuBuffer indices;
		VertexFormat.IndexType indexType;

		if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
			built.sortQuads(ALLOCATOR, RenderSystem.getProjectionType().vertexSorting());
			indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
			indexType = built.drawState().indexType();
		} else {
			RenderSystem.AutoStorageIndexBuffer shape = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
			indices = shape.getBuffer(drawState.indexCount());
			indexType = shape.type();
		}

		GpuBufferSlice dynamicTransforms = RenderSystem.getDynamicUniforms()
			.writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

		try (RenderPass pass = RenderSystem.getDevice()
			.createCommandEncoder()
			.createRenderPass(
				() -> MOD_ID + " ore render",
				client.getMainRenderTarget().getColorTextureView(),
				OptionalInt.empty(),
				client.getMainRenderTarget().getDepthTextureView(),
				OptionalDouble.empty())) {
			pass.setPipeline(pipeline);
			RenderSystem.bindDefaultUniforms(pass);
			pass.setUniform("DynamicTransforms", dynamicTransforms);
			pass.setVertexBuffer(0, vertices);
			pass.setIndexBuffer(indices, indexType);
			pass.drawIndexed(0, 0, drawState.indexCount(), 1);
		}

		built.close();
	}
}
