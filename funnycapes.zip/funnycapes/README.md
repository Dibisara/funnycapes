# Funny Capes (Fabric, Minecraft 1.21.11)

Подсвечивает алмазную и изумрудную руду (включая deepslate) сквозь стены в радиусе 24 блоков.
Клавиша O — вкл/выкл (меняется в настройках управления).

## Сборка
1. Нужны JDK 21 и Gradle wrapper. Проще всего: сгенерируйте шаблон на https://fabricmc.net/develop/template/
   (1.21.11, Mojang mappings), и скопируйте из него папку `gradle/`, `gradlew`, `gradlew.bat` в этот проект.
   Или, если Gradle установлен: `gradle wrapper --gradle-version 9.2.1`
2. `./gradlew build`
3. Готовый jar: `build/libs/funnycapes-1.0.0.jar` -> в папку mods вместе с Fabric API.

Версии в gradle.properties проверьте на https://fabricmc.net/develop/ (fabric_api_version мог обновиться).
